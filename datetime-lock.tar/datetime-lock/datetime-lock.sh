#!/bin/bash

# Script only used for systemd configuration for enable datetime-lock by start.
# Compatible with upstart.

sudo datetime-lock